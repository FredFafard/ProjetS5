/********************************************************
**  Session 5 - Projet
**  Fichier Config.h
**  Auteurs : < Projet P1 >
**  Date : < 04/04/2017 >
********************************************************/

#ifndef SOURCE_C_CONFIG_H_
#define SOURCE_C_CONFIG_H_

void DSK6713_Config(void);
void AIC23_Config(void);
void Timer1_ConfigStart(void);

#endif /* SOURCE_C_CONFIG_H_ */

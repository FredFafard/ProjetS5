clc
clear all
close all

%% VRAI DONN�ES DU DSK
%   minuscule: temporel
%   MAJUSCUL: FREQ (FFT)

nt = xlsread('notouch');        %% load 5 colonnes dans un fichier
cote = xlsread('cote');
contour = xlsread('contour');
fond = xlsread('fond');
poignee = xlsread('poignee');

nt2 = xlsread('notouch2');        %% load 5 colonnes dans un fichier
cote2 = xlsread('cote2');
contour2 = xlsread('contour2');
fond2 = xlsread('fond2');
poignee2 = xlsread('poignee2');



% n = (96000/8192)*(1:8192);

%% FFT
%   Moyenne sur 5 signaux utilis�s comme base a comparer
NT1 = 20*log10(abs(fft(nt(:,1))));
NT2 = 20*log10(abs(fft(nt(:,2))));
NT3 = 20*log10(abs(fft(nt(:,3))));
NT4 = 20*log10(abs(fft(nt(:,4))));
NT5 = 20*log10(abs(fft(nt(:,5))));
NT = (NT1+NT2+NT3+NT4+NT5)/5;

C1 = 20*log10(abs(fft(cote(:,1))));
C2 = 20*log10(abs(fft(cote(:,2))));
C3 = 20*log10(abs(fft(cote(:,3))));
C4 = 20*log10(abs(fft(cote(:,4))));
C5 = 20*log10(abs(fft(cote(:,5))));
COTE = (C1+C2+C3+C4+C5)/5;

CON1 = 20*log10(abs(fft(contour(:,1))));
CON2 = 20*log10(abs(fft(contour(:,2))));
CON3 = 20*log10(abs(fft(contour(:,3))));
CON4 = 20*log10(abs(fft(contour(:,4))));
CON5 = 20*log10(abs(fft(contour(:,5))));
CONTOUR = (CON1+CON2+CON3+CON4+CON5)/5;

F1 = 20*log10(abs(fft(fond(:,1))));
F2 = 20*log10(abs(fft(fond(:,2))));
F3 = 20*log10(abs(fft(fond(:,3))));
F4 = 20*log10(abs(fft(fond(:,4))));
F5 = 20*log10(abs(fft(fond(:,5))));
FOND = (F1+F2+F3+F4+F5)/5;

P1 = 20*log10(abs(fft(poignee(:,1))));
P2 = 20*log10(abs(fft(poignee(:,2))));
P3 = 20*log10(abs(fft(poignee(:,3))));
P4 = 20*log10(abs(fft(poignee(:,4))));
P5 = 20*log10(abs(fft(poignee(:,5))));
POIGNEE = (P1+P2+P3+P4+P5)/5;

%   Moyenne sur 5 signaux utilis�s comme deuxieme signal a comparer avec la
%   base
NT1 = 20*log10(abs(fft(nt2(:,1))));
NT2 = 20*log10(abs(fft(nt2(:,2))));
NT3 = 20*log10(abs(fft(nt2(:,3))));
NT4 = 20*log10(abs(fft(nt2(:,4))));
NT5 = 20*log10(abs(fft(nt2(:,5))));
NTt = (NT1+NT2+NT3+NT4+NT5)/5;

C1 = 20*log10(abs(fft(cote2(:,1))));
C2 = 20*log10(abs(fft(cote2(:,2))));
C3 = 20*log10(abs(fft(cote2(:,3))));
C4 = 20*log10(abs(fft(cote2(:,4))));
C5 = 20*log10(abs(fft(cote2(:,5))));
COTEt = (C1+C2+C3+C4+C5)/5;

CON1 = 20*log10(abs(fft(contour2(:,1))));
CON2 = 20*log10(abs(fft(contour2(:,2))));
CON3 = 20*log10(abs(fft(contour2(:,3))));
CON4 = 20*log10(abs(fft(contour2(:,4))));
CON5 = 20*log10(abs(fft(contour2(:,5))));
CONTOURt = (CON1+CON2+CON3+CON4+CON5)/5;

F1 = 20*log10(abs(fft(fond2(:,1))));
F2 = 20*log10(abs(fft(fond2(:,2))));
F3 = 20*log10(abs(fft(fond2(:,3))));
F4 = 20*log10(abs(fft(fond2(:,4))));
F5 = 20*log10(abs(fft(fond2(:,5))));
FONDt = (F1+F2+F3+F4+F5)/5;

P1 = 20*log10(abs(fft(poignee2(:,1))));
P2 = 20*log10(abs(fft(poignee2(:,2))));
P3 = 20*log10(abs(fft(poignee2(:,3))));
P4 = 20*log10(abs(fft(poignee2(:,4))));
P5 = 20*log10(abs(fft(poignee2(:,5))));
POIGNEEt = (P1+P2+P3+P4+P5)/5;

% FILTRE POUR SMOOTHER LA MOYENNE, on prends freq interessantes/pertinentes(1200:4096)
    ordreSmooth = 20;
  rangetest = 1200:4096;
  range = [1200:1320 1475:1550 1650:1800 2000:2400 2810:2860 3050:3150 3260:3420 3580:3680];  
  NTsmooth = smooth(NT(range),ordreSmooth);
    COTEsmooth = smooth(COTE(range),ordreSmooth);
    CONTOURsmooth = smooth(CONTOUR(range),ordreSmooth);
    FONDsmooth = smooth(FOND(range),ordreSmooth);
    POIGNEEsmooth = smooth(POIGNEE(range),ordreSmooth);
    
    % lissage des tests
    NTt = smooth(NTt(range),ordreSmooth);
    Ct = smooth(COTEt(range),ordreSmooth);
    CONt = smooth(CONTOURt(range),ordreSmooth);
    FONDt = smooth(FONDt(range),ordreSmooth);
    Pt = smooth(POIGNEEt(range),ordreSmooth);
    
    

% figure
% title('RAW FFT DATA')
% hold on
% plot(NT)
% plot(COTE)
% plot(CONTOUR)
% plot(FOND)
% plot(POIGNEE)
% legend('No touch','cote','contour','fond','poignee');

%% AFFICHAGE DES FFT SMOOTH�
figure
title('Smoothed')
hold on
plot(NTsmooth)
plot(COTEsmooth)
%plot(CONTOURsmooth)
plot(FONDsmooth)
plot(POIGNEEsmooth)
legend('No touch','cote','fond','poignee'); %'contour' % va au milieux


% Correlation moyenne avec son propre test (OUI)
OuiCorr(1) = 1 - (sum((NTsmooth-NTt).*(NTsmooth-NTt))/sum(NTsmooth.^2)); % NT (moyenne) avec NTs
OuiCorr(2) = 1 - (sum((COTEsmooth-Ct).*(COTEsmooth-Ct))/sum(COTEsmooth.^2)); 
OuiCorr(3) = 1 - (sum((CONTOURsmooth-CONt).*(CONTOURsmooth-CONt))/sum(CONTOURsmooth.^2)); 
OuiCorr(4) = 1 - (sum((FONDsmooth-FONDt).*(FONDsmooth-FONDt))/sum(FONDsmooth.^2)); 
OuiCorr(5) = 1 - (sum((POIGNEEsmooth-Pt).*(POIGNEEsmooth-Pt))/sum(POIGNEEsmooth.^2)); 

NoCorr(1) = 1 - (sum((COTEsmooth-NTt).*(COTEsmooth-NTt))/sum(COTEsmooth.^2)); 
NoCorr(2) = 1 - (sum((CONTOURsmooth-NTt).*(CONTOURsmooth-NTt))/sum(CONTOURsmooth.^2));
NoCorr(3) = 1 - (sum((FONDsmooth-NTt).*(FONDsmooth-NTt))/sum(FONDsmooth.^2)); 
NoCorr(4) = 1 - (sum((POIGNEEsmooth-NTt).*(POIGNEEsmooth-NTt))/sum(POIGNEEsmooth.^2)); 

NoCorr(5) = 1 - (sum((NTsmooth-Ct).*(NTsmooth-Ct))/sum(NTsmooth.^2)); 
NoCorr(6) = 1 - (sum((CONTOURsmooth-Ct).*(CONTOURsmooth-Ct))/sum(CONTOURsmooth.^2));
NoCorr(7) = 1 - (sum((FONDsmooth-Ct).*(FONDsmooth-Ct))/sum(FONDsmooth.^2)); 
NoCorr(8) = 1 - (sum((POIGNEEsmooth-Ct).*(POIGNEEsmooth-Ct))/sum(POIGNEEsmooth.^2)); 

NoCorr(9) = 1 - (sum((COTEsmooth-CONt).*(COTEsmooth-CONt))/sum(COTEsmooth.^2)); 
NoCorr(10) = 1 - (sum((NTsmooth-CONt).*(NTsmooth-CONt))/sum(NTsmooth.^2));
NoCorr(11) = 1 - (sum((FONDsmooth-CONt).*(FONDsmooth-CONt))/sum(FONDsmooth.^2)); 
NoCorr(12) = 1 - (sum((POIGNEEsmooth-CONt).*(POIGNEEsmooth-CONt))/sum(POIGNEEsmooth.^2)); 

NoCorr(13) = 1 - (sum((COTEsmooth-FONDt).*(COTEsmooth-FONDt))/sum(COTEsmooth.^2)); 
NoCorr(14) = 1 - (sum((NTsmooth-FONDt).*(NTsmooth-FONDt))/sum(NTsmooth.^2));
NoCorr(15) = 1 - (sum((CONTOURsmooth-FONDt).*(CONTOURsmooth-FONDt))/sum(CONTOURsmooth.^2)); 
NoCorr(16) = 1 - (sum((POIGNEEsmooth-FONDt).*(POIGNEEsmooth-FONDt))/sum(POIGNEEsmooth.^2)); 

NoCorr(17) = 1 - (sum((COTEsmooth-Pt).*(COTEsmooth-Pt))/sum(COTEsmooth.^2)); 
NoCorr(18) = 1 - (sum((NTsmooth-Pt).*(NTsmooth-Pt))/sum(NTsmooth.^2));
NoCorr(19) = 1 - (sum((CONTOURsmooth-Pt).*(CONTOURsmooth-Pt))/sum(CONTOURsmooth.^2)); 
NoCorr(20) = 1 - (sum((FONDsmooth-Pt).*(FONDsmooth-Pt))/sum(FONDsmooth.^2)); 

disp('Pas de correlation')
disp(NoCorr)
disp('Correlation')
disp(OuiCorr)
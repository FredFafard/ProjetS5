/* 
 * File:   Main.c
 * Author: Philippe Bourassa - �quipe P1
 *
 * Created on 6 avril 2017, 10:15
 */
//Includes
#include <stdio.h>
#include <stdlib.h>
#include <xc.h> 
#include <stdint.h>
#include <stdbool.h>
#include "i2c.h"
#include "pconfig.h"
#include "config_bits.h"

//Defines
#define _XTAL_FREQ 8000000 //Freq oscillation du cristal

//Prototypes de fonctions
    void config_Async_Baud();
    void config_AsyncRecep();
    void config_AsyncTransmit();
    void LCD_config();
    void config_PORTs();
    
//Fonctions
    void config_Async_Baud(){ //Voir p.415 ou p.417 pour la config
        BAUDCONbits.BRG16 = 0; //8 bits
        TXSTAbits.BRGH = 1; //Async baud rate 19.2 kHz
        SPBRG = 0x19; //25 en d�cimal
        TXSTAbits.SYNC = 0; //Async
    }
    
    void config_AsyncRecep(){ //Voir p.417 pour la config 
        PIE1bits.RC1IE = 1; //Enable intterups 
        IPR1bits.RC1IP = 1; //Reception set in High Priority
        PIR1bits.RC1IF = 0; //Initialisation du flag � 0
        
        INTCONbits.GIE = 1; //N�cessaire pour utilisation interrupt
        INTCONbits.PEIE = 1; //N�cessaire pour utilisation interrupt
        
        RCSTAbits.SPEN = 1; //Serial port enable
        RCSTAbits.RC9 = 0; //8 bits
        RCSTAbits.CREN = 1; //Enable Receiver
    }

    void config_AsyncTransmit(){ //Voir p.415 pour la config
        PIE3bits.TX2IE = 1; //Enable intterups 
        IPR3bits.TX2IP = 1; //Reception set in High Priority
        
        INTCONbits.GIE = 1; //N�cessaire pour utilisation interrupt
        INTCONbits.PEIE = 1; //N�cessaire pour utilisation interrupt
        
        TXSTAbits.TX9 = 0; //8 bits
        TXSTAbits.TXEN = 1; //Transmission Enable 
    }
    
    void LCD_config(){ //voir p.277 pour la config
       LCDPSbits.LP = 0x0; //Prescaler 1:1
       LCDSE2 = 0xFF; // Enable LCD Segment 2 (Voir pins)
       LCDPSbits.WFT = 0; //Type-A Waveform (phase change within each commun type)
       LCDPSbits.WA = 1; //Write data in LCDDATA enable
       LCDPSbits.LCDA = 1; //LCD Active Status bit
       LCDRL = 0xA0; //Power Control bits
       LCDREFbits.VLCD3PE = 1; //BIAS3 level is connected to the external pin, LCDBIAS3
       LCDREFbits.VLCD2PE = 1; //BIAS3 level is connected to the external pin, LCDBIAS2
       LCDREFbits.VLCD1PE = 1; //BIAS3 level is connected to the external pin, LCDBIAS1
       LCDREFbits.LCDIRE = 1; //Enable Internal Reference
       LCDCON = 0x82; //LCD driver module & commons selec bits **
    }
    
    void config_PORTs(){
        PORTG = 0;
        LATG = 0;
        TRISG = 0x04;
    }
        
//Programme Principal
int main() {
    
    //Configurations initiales
        config_Async_Baud();
        config_AsyncRecep();
        config_AsyncTransmit();
        LCD_config();
        config_PORTs();
        
    //Boucle de commande
        while(1){
           PORTG = 0xFF; //Allume les leds du board pour test

        }
    return (EXIT_SUCCESS);
}


le dossier testSOupe contient les tests s�par�s.

les .xlsx ont 5 colonnes pour chaque tests.
on fait la FFT, puis la moyenne des 5
/*
 * main.h
 *
 *  Created on: 15 mars 2017
 *      Author: faff2302
 */

#ifndef SOURCE_H_MAIN_H_
#define SOURCE_H_MAIN_H_

void Demo_Corr();
void configAndStartTimer1(void);
void enableInterrupts(void);


#endif /* SOURCE_H_MAIN_H_ */

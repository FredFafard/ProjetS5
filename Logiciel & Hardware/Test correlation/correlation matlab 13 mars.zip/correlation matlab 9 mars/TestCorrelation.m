clc; clear all; close all;

%Correlation selon nos APP:
% Document D6-9-1 page 230
% sum(x1(:,2)*x2(:,2))

% Correlation utilisee (Correlation normalisee sur une valeur de 1):
%  1- sum((X1(:,2)-X2(:,2))^2)/sum(X1(:,2)^2)

%Les (:,2) sont pour aller chercher les valeurs dans la deuxieme colonne.
%La premiere colonne sont les index


x1 = xlsread('Bas1');
x2 = xlsread('Bas2');
x3 = xlsread('Bas3');

x4 = xlsread('NoTouch');
x5 = xlsread('Haut');
[m,n] = size(x1);
xzeros = zeros(m,1);
xzeros(:,2) = xzeros(:,1);
xzeros(:,1) = x1(:,1); %Pour ecrire les index

%Resultat de correlation avec xcorr

xcorr1 = xcorr(x1(:,2),x1(:,2));
xcorr2 = xcorr(x1(:,2),x3(:,2));
xcorr1(1006)
xcorr2(1006)

%Resultats de correlation a la main
r1 = 1 - (sum((x1(:,2)-x3(:,2)).*(x1(:,2)-x3(:,2)))/sum(x1(:,2).^2)); %Bas1 et Bas3
r2 = 1 - (sum((x2(:,2)-x3(:,2)).*(x2(:,2)-x3(:,2)))/sum(x2(:,2).^2)); %Bas2 et Bas3
r3 = 1 - (sum((x2(:,2)-x1(:,2)).*(x2(:,2)-x1(:,2)))/sum(x2(:,2).^2)); %Bas1 et Bas2
r4 = 1 - (sum((x1(:,2)-x4(:,2)).*(x1(:,2)-x4(:,2)))/sum(x1(:,2).^2)); %Bas1 et Notouch
r5 = 1 - (sum((x2(:,2)-x4(:,2)).*(x2(:,2)-x4(:,2)))/sum(x2(:,2).^2)); %Bas2 et Notouch
r6 = 1 - (sum((x3(:,2)-x4(:,2)).*(x3(:,2)-x4(:,2)))/sum(x3(:,2).^2)); %Bas3 et notouch
r7 = 1 - (sum((x1(:,2)-x5(:,2)).*(x1(:,2)-x5(:,2)))/sum(x1(:,2).^2)); %Bas1 et Haut
r8 = 1 - (sum((x2(:,2)-x5(:,2)).*(x2(:,2)-x5(:,2)))/sum(x2(:,2).^2)); %Bas2 et Haut
r9 = 1 - (sum((x3(:,2)-x5(:,2)).*(x3(:,2)-x5(:,2)))/sum(x3(:,2).^2)); %Bas3 et Haut
r10 = 1 - (sum((x1(:,2)-x1(:,2)).*(x1(:,2)-x1(:,2)))/sum(x1(:,2).^2)); %correlation parfaite de 1
r11 = 1 - (sum((x1(:,2)-xzeros(:,2)).*(x1(:,2)-xzeros(:,2)))/sum(x1(:,2).^2)); %correlation nulle (avec zero)

x1 = [2 0 1 4 0 1 3 4];
x2 = [3 4 1];

xcorr(x1,x2)
m = length(x1);
n = length(x2);
for k=1:1:m-1
    x2(n+k) = 0;
end
x1(n:n+m-1) = x1;
for k=1:1:n-1
    x1(k) = 0;
end
for k=1:1:m+n-1
    xcorrmanuel(k) = sum(x1((m-k+n):end).*x2(1:k))
end

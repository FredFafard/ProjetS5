clear all;close all;clc;


%s = xlsread('Q:\projet\Classeur1.xlsx');

spectreCCS( 'Q:\projet\Classeur1.xlsx' )

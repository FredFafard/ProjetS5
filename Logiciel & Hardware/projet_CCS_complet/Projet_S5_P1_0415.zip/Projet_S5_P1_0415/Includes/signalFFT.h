/*
 * test_fft.h
 *
 *  Created on: 15 mars 2017
 *      Author: faff2302
 */

#ifndef SOURCE_C_TEST_FFT_H_
#define SOURCE_C_TEST_FFT_H_

void signalFFT(float signal[], float fft_signal[]);

#endif /* SOURCE_C_TEST_FFT_H_ */
